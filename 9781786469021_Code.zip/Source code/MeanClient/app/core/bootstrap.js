/**
 * Created by chrisp on 11/02/2017.
 */
'use strict';


let appModule = require('../app');


angular.bootstrap(document, [appModule.name], { strictDi: true });
