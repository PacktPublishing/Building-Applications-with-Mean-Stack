'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [
    'ui.router',
    () => {
        require("./view1/view1");
        return 'myApp.view1'
    }
    ,
    () => {
        require("./view2/view2");
        return 'myApp.view2'
    },
    () => {
        require("./components/version/version");
        return 'myApp.version'
    }

]).config(['$locationProvider', '$routeProvider', function ($locationProvider, $routeProvider) {
    $locationProvider.hashPrefix('!');

    $routeProvider.otherwise({redirectTo: '/view1'});
}]);
