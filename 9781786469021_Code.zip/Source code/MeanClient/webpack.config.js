
const path = require('path').resolve;
const isProd = process.env.NODE_ENV === 'production';
const webpack = require('webpack');
const validate = require('webpack-validator');
const HtmlWebpackPlugin = require('html-webpack-plugin');


module.exports = env => {
    const addPlugin = (add,plugin) => add? plugin: undefined;
    const ifProd =  plugin => addPlugin(env.prod, plugin);
    const removeEmpty = array => array.filter(i=> !!i);
    return validate({
        entry: {
            app: "./core/bootstrap.js",
            vendor_first :[ 'angular','angular-route'],
            // vendor_second: ['angular-aria','angular-animate'],
            // vendor_second: ['angular-route'],
        },
        output: {
            path: path( __dirname , 'dist/'),
            filename: 'bundle.[name].js',
            // pathinfo: !env.prod
            pathinfo: true
        },

        context: path(__dirname, 'app/'),
        devtool: isProd ?'source-map': 'eval',
        bail: env.prod,
        module: {
            noParse: [],
            loaders: [
                {
                    test: /\.js$/,
                    exclude: /node_modules/,
                    loader: 'ng-annotate!babel'
                },
                // {
                //     test: /\.html$/,
                //     loader: 'raw'
                // },
                {
                    test: /\.css$/,
                    loader: 'style!css'
                },

            ]
        },
        plugins :
            removeEmpty([
                ifProd(new webpack.optimize.DedupePlugin()),
                ifProd(new webpack.LoaderOptionsPlugin({
                    minimise: true,
                    debug : false
                })),
                ifProd(
                    new webpack.DefinePlugin({
                    'process.env':{
                        NODE_ENV : '"production"',
                        PORT: '3000'
                    }
                })),
                ifProd(new webpack.optimize.UglifyJsPlugin({
                    compress: {
                        screw_ie8: true, //eslint-disable-line
                        warnings :false,
                    }
                })),
                 new webpack.optimize.CommonsChunkPlugin({
                    names :[/*'vendor_second',*/'vendor_first'],
                    filenames: [/*"bundle.vendor_second.js",*/"bundle.vendor_first.js"],
                     // async: true
                }),
                 new HtmlWebpackPlugin({
                    template : './index.html'
                })

            ])

    })
};

