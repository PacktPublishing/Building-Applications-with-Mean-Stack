/**
 * Created by Eng Chrispinus on 10/12/2016.
 */


/*eslint no-console: ["error", { allow: ["warn", "error", "log", "dir"] }] */

var express, wagner, path, logger, app, parser, server;


express = require("express");
wagner = require("wagner-core");
path = require("path");
logger = require("morgan");
parser = require("body-parser");


require("./models/models")(wagner);

// require("./public/javascripts/server/dependencies")(wagner);
// .

app = express()();
server = require("http").Server(app);
app.io = require("socket.io")(server);

app.use(logger("dev"));



// wagner.invoke(require("./public/javascripts/server/auth"),{app:app});
// app.use(express.static(path.join(__dirname, "public"),{ maxAge: 4 * 60 * 60 * 1000 /* 2hrs */ }));

app.on("mount", function (parent) {
	app.io = parent.io;
});

app.use(parser.json());



app.use("/api/v1", require("./routes/api")(wagner));
//ADD client
app.use("/vendor", express.static(path.join(__dirname, "..", "..", "..", "node_modules")));
app.use(express.static(path.join(__dirname, "..", "..", "src")));
app.use(function (req, res) {
	res.sendFile(path.join(__dirname, "..", "..", "src", "index.html"));
});


app.use((req, res, next) => {
	let err = new Error("Not Found");
	err.status = 404;
	next(err);
});

if (app.get("env") === "development") {
	app.use((err, req, res, next) => {
		res.status(err.status || 500);
		res.render("error", {
			message: err.message,
			error: err
		});
		next();
	});
}


app.listen (3000);

console.log("Listening at port 3000");


