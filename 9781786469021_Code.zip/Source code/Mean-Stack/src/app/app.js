import angular from 'angular';
import 'angular-route';
import 'angular-resource';
import 'body-parser';
import 'bootstrap';


import '../style/app.css';


let app = () => {
    return {
        template: require('./view/home.html'),
        controller: 'AppCtrl',
        controllerAs: 'app'
    }
};

class AppCtrl {
    constructor() {
        this.url = 'https://';
    }
}

const MODULE_NAME = 'donorApp';
const MODULE_EXTERNAL =  ['ngRoute', 'ngResource'];


angular.module(MODULE_NAME, MODULE_EXTERNAL)
    .directive('app', app)
    .controller('AppCtrl', AppCtrl)
    .config(function($routeProvider, $locationProvider) {
        $routeProvider.when('/', {
            templateUrl: './view/list.html'
        });

        $routeProvider.when('/manage/:donator', {
            templateUrl: './view/donator-form.html',
            controller: 'DonatorManager',
            resolve: {
                donator: function ($route, $location, Donators) {
                    var donator = Donators.get({id: $route.current.params.donator});
                    donator.$promise.catch(function () {
                        $location.url('/');
                    });
                    return donator;
                }
            }
        });

        $routeProvider.when('/view/:donator', {
            templateUrl: './view/donator-card.html',
            controller: 'DonatorManager',
            resolve: {
                donator: function ($route, $location, Donators) {
                    var donator = Donators.get({id: $route.current.params.donator});
                    donator.$promise.catch(function () {
                        $location.url('/');
                    });
                    return donator;
                }
            }
        });

        $routeProvider.when('/become', {
            templateUrl: './view/donator-form.html',
            controller: 'DonatorManager',
            resolve: {
                donator: function ($route, Donators) {
                    return new Donators();
                }
            }
        });

        $routeProvider.otherwise({
            redirectTo: '/'
        });

        $locationProvider.html5Mode(true);
    });


export default MODULE_NAME;

require("./include");