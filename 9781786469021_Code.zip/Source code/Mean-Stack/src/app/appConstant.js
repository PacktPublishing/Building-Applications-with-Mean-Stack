module.exports = (function(angular, undefined) {
'use strict';

angular.module('donorApp.constants', [])

.constant('appConfig', {userRoles:['guest','user','admin']})

})(angular);